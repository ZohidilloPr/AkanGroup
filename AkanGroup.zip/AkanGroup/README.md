how to run this app >

install python 3 on PC

in command line > cd C:\Users\<username>\<folder location>\AkanGroup>

on windows
$  akan-env\Scripts\activate

on linux
$  source akan-env/bin/activate

$  python manage.py runserver

"""
    localhost = 127.0.0.1:8000 

"""

"""
    sending emails with SendGrid servise

"""